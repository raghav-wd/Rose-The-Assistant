<?php
include_once "../utilities.php";
$str = $_GET["q"];
$str = removeNonKeywords($str);
$str = removeWords($str, ["birthday"]);
$myfile = fopen("../birthday.json", "a+") or die("Unable to open file!");
$strArr = explode(" ", trim($str));
$name = strtolower($strArr[0]);
$date = strtolower($strArr[1]);
$month = strtolower($strArr[2]);
$year = (isset($strArr[3]))?$strArr[3]:"";
print_r($strArr);
fwrite($myfile, ',"'.$month.' '.$date.'" :'.'"'.$name.'"');
echo $str;