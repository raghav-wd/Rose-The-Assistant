<?php
// echo file_get_contents("category.json");
header("Content-type:application/json");
include_once "utilities.php";
    $q = $_GET["q"];
    // needData("weather of chennai");
    needData($q);
    function needData($str)
    {
        $apis = file_get_contents("category.json");
        $apis = json_decode($apis, true);
        $reply = "idk";
        for($i = 0; $i<count($apis["apis"]["apisName"]); $i++)
        {
            if(inString($str, $apis["apis"]["apisKws"][$i]))
            {
                include_once "classes/".$apis["apis"]["apisName"][$i].".php";
                $instance = new $apis["apis"]["apisName"][$i];
                $reply = $instance->useApi($str);
                if($reply != "")
                echo $reply;
                break;        
            }
        }
        if($reply == "idk" && strAnalyser($str)->isQuestioned != "user_info")
        {
            $ai = file_get_contents("ai.json");
            $ai = json_decode($ai, true);
            $kw = trim(removeNonKeywords($str));
            $reply = $ai[$kw];
            if(gettype($reply) == 'array')
            $reply = $reply[rand(0, count($reply)-1)];
            echo '{"result": "'.$reply.'"}';
        }
    }

// echo '{"id": "dkjf"}';
















    // include_once "utilities.php";
    // $q = $_GET["q"];
    // needData($q);
    // function needData($str)
    // {
    //     $apis = file_get_contents("category.json");
    //     $apis = json_decode($apis, true);
    //     for($i = 0; $i<100; $i++)
    //     {
    //         if(inString($str, $apis["apis"]["apisKws"][$i]))
    //         {
    //             include_once "classes/".$apis["apis"]["apisName"][$i].".php";
    //             $instance = new $apis["apis"]["apisName"][$i];
    //             echo $instance->useApi($str);
    //             break;        
    //         }
    //         // else break;
    //     }
    // }