<?php
class Schedule {
    function useApi($str) {
            $def_timetable = "third sem";
            $def_mess = "pf";

            $json = file_get_contents("schedule.json");
            $json = json_decode($json, true);

            // $day = $_GET['day'];
            // $time = $_GET['time'];

            $dayKWs = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "today", "tomorrow", "yesterday"];
            // $slots = $json["third sem"]["slots"];
            $day = getIndex(strtolower(date("l")), $dayKWs);
            $time = 480;
            // $day = 1;

            $str = removeNonKeywords($str);
            $askedSchedule = trim(removeWords($str, ["today", "tomorrow", "now", "yesterday", "get", "mess", "timetable"]));

            for($i = 0; $i<3; $i++)
            {
                if(inString($str, $json["dictionary"][$i]) > 0)
                {
                    $key = $json["dictionary"]["scheduleNames"][$i];
                    $obj = new Class{};
                    for($j = 0; $j<count($json[$key]["slotNames"]); $j++)
                    {
                        $objProp = $json[$key]["slotNames"][$j];
                        // $isArray = json_decode($json[$key][$day][$j], true);
                        // if(gettype($isArray) == "array")
                        $obj->$objProp = $json[$key][$day][$j];
                        // else $obj->greetings = $json[$key][$day];
                    }
                    echo json_encode($obj);
                }
                // else break;
            }

            // if(inString($str, $dayKWs))
            // {
            //     $index = getIndex($str, $dayKWs);
            //     if($index < 7)
            //     $day = $index;
            //     if($index == 8)
            //     $day = ($day == 0)?0:$day+1;
            //     else if($index == 9)
            //     $day = ($day == 6)?0:$day-1;
            //     return json_encode($json[$def_timetable][$day]);
            // }
    }
}




















// class Schedule {
//     function useApi($str) {
//             $def_timetable = "third sem";
//             $def_mess = "pf";

//             $json = file_get_contents("schedule.json");
//             $json = json_decode($json, true);

//             $day = $_GET['day'];
//             $time = $_GET['time'];

//             $dayKWs = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "today", "tomorrow", "yesterday"];
//             $presKWs = ["previous", "now", "next"];
//             $slots = $json["third sem"]["slots"];

//             if(inString($str, $dayKWs, false))
//             {
//                 $index = getIndex($str, $dayKWs);
//                 if($index < 7)
//                 $day = $index;
//                 if($index == 8)
//                 $day = ($day == 0)?0:$day+1;
//                 else if($index == 9)
//                 $day = ($day == 6)?0:$day-1;
//                 return json_encode($json[$def_timetable][$day]);
//             }
//     }
// }