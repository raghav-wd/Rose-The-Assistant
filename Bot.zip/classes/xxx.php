<?php
$res = exec("Dictionary.py");
echo $res;