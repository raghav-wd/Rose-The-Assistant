<?php
class Google{
    function useApi($str){
        $str = removeWords($str, ["google"]);
        $URL = "https://www.google.com/search?q=".$str;
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache"
        ),
        ));

        $response = curl_exec($curl);
        // $start = strpos($htm, '<meta name="description" content="');
        // $end = strpos($htm, 'See more.">');
        // $meaning = substr($htm, $start+34, $end);
        // $meaning = chopStrs($meaning, ['See more.">']);
        return $response;
    }
}