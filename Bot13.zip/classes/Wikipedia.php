<?php
class Wikipedia {
    function useApi($str){
            $filter = chopStrs($str, ["search"]);
            $data = apiFetch("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=".$filter."&utf8=&format=json");
            $wikiPageTitle = $data["query"]["search"][0]["title"];
            $data = apiFetch("https://en.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro=&explaintext=&titles=". $wikiPageTitle);
            $arr = array_keys($data["query"]["pages"]);
            $obj = new Class{};
            $obj->ai = "";
            $obj->pageTitle = $wikiPageTitle;
            $obj->result = $data["query"]["pages"][$arr[0]]["extract"];
            $obj->source = "Wikipedia";
            $json = json_encode($obj);
            echo $json;
    }
}